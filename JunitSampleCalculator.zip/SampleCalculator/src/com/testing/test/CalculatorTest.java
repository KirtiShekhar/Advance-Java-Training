package com.testing.test;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.TestMethodOrder;
import org.junit.jupiter.api.Timeout;
import static org.junit.jupiter.api.Assertions.assertEquals;
import java.util.concurrent.TimeUnit;
import java.util.stream.Stream;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.MethodOrderer.OrderAnnotation;
import org.junit.jupiter.api.TestInstance.Lifecycle;
import org.junit.jupiter.api.condition.EnabledOnOs;
import org.junit.jupiter.api.condition.OS;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.CsvSource;
import org.junit.jupiter.params.provider.MethodSource;
import org.junit.jupiter.params.provider.ValueSource;
import com.testing.samplecalculator.SampleCalculator;

@TestInstance(Lifecycle.PER_CLASS)
@TestMethodOrder(OrderAnnotation.class)
class CalculatorTest 
{
	SampleCalculator sampleCalculator;

	@BeforeEach
	public void setup()
	{
		sampleCalculator = new SampleCalculator();
	}

	static class NestedCalculatorTest
	{
		@Test
		public void empty_method()
		{
			//
		}

		@ParameterizedTest(name = "Parameterized Test cases {0}")
		@ValueSource(strings = {"Kirti" , "Manas Singh" , "Abhinav Kumar Singh"})
		public void readNames(String inputstr)
		{
			System.out.println("Inputs read from source is " + inputstr);
		}

		@ParameterizedTest
		@CsvSource({"Kirti,26", "Manas Singh,25", "Saurav,27"})
		public void testParameters(String name, int age) {
			System.out.println("csv data : name " + name + " age " + age);
		}

		@ParameterizedTest
		@MethodSource("provideParameters")
		public void testParametersFromMethod(String[] name, int age) {
			System.out.println("method data " + name[0]+" "+name[1] + " value " + age);
		}

		private static Stream<Arguments> provideParameters() {
			return Stream.of(
					Arguments.of("'Kirti'", 26),
					Arguments.of("'Manas Singh'", 25));
		}

		@Test
		@Timeout(5)
		public void gmpty_method() {
			try {
				TimeUnit.SECONDS.sleep(5);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}

	}

	@Test
	@Order(6)
	@DisplayName("Addition Function Test")
	@EnabledOnOs(OS.WINDOWS)
	void testAddition() 
	{
		int additionresult = sampleCalculator.addition(20, 80);
		assertEquals(100, additionresult);
		System.out.println("Current Object 6 Addition Function : " + this);
	}

	@Test
	@Order(3)
	@DisplayName("Subtraction Function Test")
	void testSubtraction() 
	{
		int subtractionresult = sampleCalculator.subtraction(40, 20);
		assertEquals(20, subtractionresult);
		System.out.println("Current Object 3 Subtraction Function : " + this);
	}

	@Test
	@Order(5)
	@DisplayName("Multiplication Function Test")
	void testMultiplication() 
	{
		int multiplicationresult = sampleCalculator.multiplication(40, 20);
		assertEquals(800, multiplicationresult);
		System.out.println("Current Object 5 Multiplication Function : " + this);
	}

	@Test
	@Order(7)
	@DisplayName("Division Function Test")
	void testDivision() 
	{
		int divisionresult = sampleCalculator.division(40, 20);
		assertEquals(2, divisionresult);
		System.out.println("Current Object 7 Division Function : " + this);
	}

	@Test
	@Order(4)
	@DisplayName("Modulus Function Test")
	void testModulus() 
	{
		int modulusresult = sampleCalculator.modulus(30, 4);
		assertEquals(2, modulusresult);
		System.out.println("Current Object 4 Modulus Function : " + this);
	}

	@Test
	@Order(1)
	@DisplayName("Square Function Test")
	void testSquare()
	{
		int squareresult = sampleCalculator.square(9);
		assertEquals(81, squareresult);
		System.out.println("Current Object 1 Square Function : " + this);
	}

	@Test
	@Order(2)
	@DisplayName("Cube Function Test")
	void testCube() 
	{
		int cuberesult = sampleCalculator.cube(9);
		assertEquals(729, cuberesult);
		System.out.println("Current Object 2 Cube Function : " + this);
	}

}

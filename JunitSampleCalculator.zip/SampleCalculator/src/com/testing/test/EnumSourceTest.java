package com.testing.test;

import static org.junit.jupiter.api.Assertions.assertTrue;
import java.time.Month;
import static org.junit.jupiter.api.Assertions.assertEquals;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.EnumSource;

class EnumSourceTest {

	@ParameterizedTest
	@EnumSource(Month.class)
	void getValueForAMonth_IsAlwaysBetweenOneAndTwelve(Month month) 
	{
		int monthNumber = month.getValue();
		assertTrue(monthNumber >= 1 && monthNumber <= 12);
	}
	
	@ParameterizedTest
	@EnumSource(value = Month.class , names = {"JANUARY","MARCH","MAY","JULY","AUGUST","OCTOBER","DECEMBER"})
	void someMonths_Are31DaysLong(Month month) 
	{
		assertEquals(31 , month.length(false));
	}
	
	@ParameterizedTest
	@EnumSource(value = Month.class , names = {"APRIL","JUNE","SEPTEMBER","NOVEMBER"})
	void someMonths_Are30DaysLong(Month month) 
	{
		assertEquals(30 , month.length(false));
	}
}

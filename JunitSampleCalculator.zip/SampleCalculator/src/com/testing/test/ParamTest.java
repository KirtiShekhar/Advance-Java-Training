package com.testing.test;

import static org.junit.jupiter.api.Assertions.assertTrue;
import java.util.concurrent.TimeUnit;
import org.junit.jupiter.api.RepeatedTest;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.Timeout;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.converter.ConvertWith;
import org.junit.jupiter.params.provider.CsvSource;
import org.junit.jupiter.params.provider.MethodSource;
import org.junit.jupiter.params.provider.NullSource;
import org.junit.jupiter.params.provider.ValueSource;
import java.util.stream.Stream;
import org.junit.jupiter.params.provider.Arguments;

public class ParamTest {

	@ParameterizedTest(name = "Parameterized Test cases {0}")
	@ValueSource(strings = {"Kirti" , "Manas Singh" , "Abhinav Kumar Singh"})
	public void readNames(String inputstr)
	{
		System.out.println("Inputs read from source is " + inputstr);
	}

	@ParameterizedTest()
	@CsvSource({"Kirti Shekhar Pandey,26", "Vinay,25", "Saurav,27"})
	public void testParameters(String name, int age) {
		System.out.println("csv data : name " + name + " age " + age);
	}

	@ParameterizedTest
	@MethodSource("provideParameters")
	public void testParametersFromMethod(@ConvertWith(StringArrayConverter.class)String[] name, int value) {
		System.out.println("method data : Name => " + name[0]+" "+name[1] + " Age => " + value);
	}
	
	private static Stream<Arguments> provideParameters() {
	    return Stream.of(
	            Arguments.of("'kirti,shekhar pandey'", 25),
	            Arguments.of("'manas,singh'", 29)
	    );
	}

	@RepeatedTest(9)
	public void repeatingTest()
	{
		System.out.println("Repeating Test ....");
	}

	@ParameterizedTest
	@NullSource
	void isBlank_ShouldReturnTrueForNullInputs(String input) 
	{
		assertTrue(StringsUtil.isBlank(input));
	}

	@Test
	@Timeout(20)
	public void gmpty_method() {
		try {
			TimeUnit.SECONDS.sleep(20);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

	static public class StringsUtil
	{
		public static boolean isBlank(String inputstr)
		{
			return inputstr == null || inputstr.trim().isEmpty();
		}
	}


}

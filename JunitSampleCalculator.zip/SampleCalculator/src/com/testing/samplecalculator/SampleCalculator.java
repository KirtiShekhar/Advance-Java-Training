package com.testing.samplecalculator;

public class SampleCalculator 
{
	public int addition(int a, int b) 
	{
		return a + b;
	}

	public int subtraction(int c,int d)
	{
		return c - d;
	}

	public int multiplication(int a , int b)
	{
		return a * b;
	}

	public int division(int c,int d)
	{
		return c / d;
	}
	
	public int modulus(int a,int b)
	{
		return a % b;
	}
	
	public int square(int x)
	{
		return x * x;
	}
	
	public int cube(int y)
	{
		return y * y * y;
	}

}

package com.springboot.customerbank.service;

import java.util.List;
import com.springboot.customerbank.dto.TransactionRequestDto;
import com.springboot.customerbank.dto.TransactionResponseDto;

public interface TransactionService 
{
	void saveTransaction(TransactionRequestDto transactionRequestDto);
	List<TransactionResponseDto> getAllTransactions();
}
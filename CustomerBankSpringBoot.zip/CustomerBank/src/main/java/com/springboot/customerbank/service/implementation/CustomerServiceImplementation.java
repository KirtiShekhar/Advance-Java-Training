package com.springboot.customerbank.service.implementation;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Optional;
import java.util.OptionalInt;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.springboot.customerbank.dto.CustomerRequestDto;
import com.springboot.customerbank.dto.CustomerResponseDto;
import com.springboot.customerbank.entity.Customer;
import com.springboot.customerbank.repository.CustomerRepository;
import com.springboot.customerbank.service.CustomerService;

@Service
public class CustomerServiceImplementation implements CustomerService 
{
	@Autowired
	CustomerRepository customerRepository;

	public void saveCustomerDetails(CustomerRequestDto customerRequestDto) 
	{
		Customer customer = new Customer();
		BeanUtils.copyProperties(customerRequestDto, customer);
		customerRepository.save(customer);
	}

	public List<CustomerResponseDto> getCustomerDetails() 
	{
		List<CustomerResponseDto> customerResponseDto = new ArrayList<>();
		Iterator iterator = customerRepository.findAll().iterator();
		while(iterator.hasNext())
		{
			CustomerResponseDto customerResponseDtos = new CustomerResponseDto();
			BeanUtils.copyProperties(iterator.next(),customerResponseDtos);
			customerResponseDto.add(customerResponseDtos);
		}
		return customerResponseDto;
	}

	public List<CustomerResponseDto> getCustomerDetails(String customerName) {
		List<CustomerResponseDto> customerResponseDtoList = new ArrayList<>();
		List<Customer> customerList = customerRepository.findByCustomerName(customerName);
		for(Customer customer : customerList)
		{
			CustomerResponseDto customerResponseDto = new CustomerResponseDto();
			BeanUtils.copyProperties(customer, customerResponseDto);
			customerResponseDtoList.add(customerResponseDto);
		}
		return customerResponseDtoList;
	}

	public CustomerResponseDto getCustomerDetails(Integer customerId) {
		Customer customer = new Customer();
		CustomerResponseDto customerResponseDto = new CustomerResponseDto();
		Optional<Customer> optionalCustomers = customerRepository.findById(customerId);
		if(optionalCustomers.isPresent())
		{
			customer = optionalCustomers.get();
		}
		BeanUtils.copyProperties(customer, customerResponseDto);
		return customerResponseDto;
	}

	@Override
	public void deleteCustomerDetails(Integer customerId) 
	{
		customerRepository.deleteById(customerId);	
	}
}

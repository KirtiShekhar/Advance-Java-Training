package com.springboot.customerbank.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import com.springboot.customerbank.dto.TransactionRequestDto;
import com.springboot.customerbank.dto.TransactionResponseDto;
import com.springboot.customerbank.service.TransactionService;

@RestController
public class TransactionController 
{
	@Autowired
	TransactionService transactionService;
	
	@PostMapping("/savetransaction")
	public String saveTransaction(@RequestBody TransactionRequestDto transactionRequestDto)
	{
		transactionService.saveTransaction(transactionRequestDto);
		return "Entered Transaction Detail Added Successfullt"; 
	}
		
	@GetMapping("/getalltransaction")
	public List<TransactionResponseDto> getAllAccountDetails()
	{
		return transactionService.getAllTransactions();
	}
}
package com.springboot.customerbank.service;

import java.util.List;
import com.springboot.customerbank.dto.AccountRequestDto;
import com.springboot.customerbank.dto.AccountResponseDto;

public interface AccountService 
{
	AccountResponseDto saveAccountInformation(AccountRequestDto accountRequestDto);
	List<AccountResponseDto> getAllAccountInformation();
}
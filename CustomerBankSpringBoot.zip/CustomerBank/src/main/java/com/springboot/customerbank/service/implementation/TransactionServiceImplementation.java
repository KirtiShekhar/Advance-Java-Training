package com.springboot.customerbank.service.implementation;

import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.springboot.customerbank.dto.TransactionRequestDto;
import com.springboot.customerbank.dto.TransactionResponseDto;
import com.springboot.customerbank.entity.Transaction;
import com.springboot.customerbank.repository.TransactionRepository;
import com.springboot.customerbank.service.TransactionService;

@Service
public class TransactionServiceImplementation implements TransactionService 
{
	@Autowired
	TransactionRepository transactionRepository;

	@Override
	public void saveTransaction(TransactionRequestDto transactionRequestDto) 
	{
		Transaction transaction = new Transaction();
		BeanUtils.copyProperties(transactionRequestDto, transaction);
		transactionRepository.save(transaction);
	}

	@Override
	public List<TransactionResponseDto> getAllTransactions() 
	{
		List<TransactionResponseDto> transactionResponseDto = new ArrayList<>();
		Iterator iterator = transactionRepository.findAll().iterator();
		while(iterator.hasNext())
		{
			TransactionResponseDto transactionResponseDtos = new TransactionResponseDto();
			BeanUtils.copyProperties(iterator.next(),transactionResponseDtos);
			transactionResponseDto.add(transactionResponseDtos);
		}
		return transactionResponseDto;
	}

}

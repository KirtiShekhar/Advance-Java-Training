package com.springboot.customerbank.service.implementation;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Optional;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.springboot.customerbank.dto.AccountRequestDto;
import com.springboot.customerbank.dto.AccountResponseDto;
import com.springboot.customerbank.entity.Account;
import com.springboot.customerbank.repository.AccountRepository;
import com.springboot.customerbank.repository.CustomerRepository;
import com.springboot.customerbank.service.AccountService;
import com.springboot.customerbank.entity.Customer;
import com.springboot.customerbank.exception.CustomerNotFoundException;

@Service
public class AccountServiceImplementation implements AccountService 
{
	@Autowired
	AccountRepository accountRepository;

	@Autowired
	CustomerRepository customerRepository;

	@Override
	public AccountResponseDto saveAccountInformation(AccountRequestDto accountRequestDto) 
	{
		Optional<Customer> optionalCustomer = customerRepository.findById(accountRequestDto.getCustomerId());
		if(optionalCustomer.isPresent())
		{
			Account account=new Account();
			BeanUtils.copyProperties(accountRequestDto, account);
			account=accountRepository.save(account);
			AccountResponseDto accountResponseDto=new AccountResponseDto();
			BeanUtils.copyProperties(account, accountResponseDto);
			return accountResponseDto;
		}

		throw new CustomerNotFoundException("Customer doesn't exist for this id"+" "+accountRequestDto.getCustomerId());

	}

	@Override
	public List<AccountResponseDto> getAllAccountInformation() 
	{
		List<AccountResponseDto> accountResponseDto = new ArrayList<>();
		Iterator iterator = accountRepository.findAll().iterator();
		while(iterator.hasNext())
		{
			AccountResponseDto accountResponseDtos = new AccountResponseDto();
			BeanUtils.copyProperties(iterator.next(),accountResponseDtos);
			accountResponseDto.add(accountResponseDtos);
		}
		return accountResponseDto;
	}

}

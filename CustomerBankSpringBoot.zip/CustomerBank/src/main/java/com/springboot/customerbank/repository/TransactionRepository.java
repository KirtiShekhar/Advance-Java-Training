package com.springboot.customerbank.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import com.springboot.customerbank.entity.Transaction;

@Repository
public interface TransactionRepository extends CrudRepository<Transaction,Integer> {

}

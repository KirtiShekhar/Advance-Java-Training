package com.springboot.customerbank.service;

import java.util.List;
import com.springboot.customerbank.dto.CustomerRequestDto;
import com.springboot.customerbank.dto.CustomerResponseDto;

public interface CustomerService 
{
	void saveCustomerDetails(CustomerRequestDto customerRequestDto);
	List<CustomerResponseDto> getCustomerDetails(String customerName);
	List<CustomerResponseDto> getCustomerDetails();
	CustomerResponseDto getCustomerDetails(Integer customerId);
	void deleteCustomerDetails(Integer customerId);
}

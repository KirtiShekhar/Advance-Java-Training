package com.springboot.customerbank;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CustomerBankApplication {

	public static void main(String[] args) {
		SpringApplication.run(CustomerBankApplication.class, args);
	}

}

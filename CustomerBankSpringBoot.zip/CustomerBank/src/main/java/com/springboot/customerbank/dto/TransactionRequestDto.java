package com.springboot.customerbank.dto;

import java.sql.Date;

public class TransactionRequestDto
{
	private String transactionNumber;
	private double amount;
	private String transactionType;
	private Integer accountid;
	private Date transactionDate;
	
	public TransactionRequestDto() {}

	public TransactionRequestDto(String transactionNumber, double amount, String transactionType, Integer accountid,
			Date transactionDate) {
		super();
		this.transactionNumber = transactionNumber;
		this.amount = amount;
		this.transactionType = transactionType;
		this.accountid = accountid;
		this.transactionDate = transactionDate;
	}

	public String getTransactionNumber() {
		return transactionNumber;
	}

	public void setTransactionNumber(String transactionNumber) {
		this.transactionNumber = transactionNumber;
	}

	public double getAmount() {
		return amount;
	}

	public void setAmount(double amount) {
		this.amount = amount;
	}

	public String getTransactionType() {
		return transactionType;
	}

	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}

	public Integer getAccountid() {
		return accountid;
	}

	public void setAccountid(Integer accountid) {
		this.accountid = accountid;
	}

	public Date getTransactionDate() {
		return transactionDate;
	}

	public void setTransactionDate(Date transactionDate) {
		this.transactionDate = transactionDate;
	}
	
	
}
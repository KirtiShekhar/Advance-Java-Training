package com.springboot.customerbank.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import javax.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import com.springboot.customerbank.dto.AccountRequestDto;
import com.springboot.customerbank.dto.AccountResponseDto;
import com.springboot.customerbank.exception.CustomerNotFoundException;
import com.springboot.customerbank.service.AccountService;

@RestController
public class AccountController 
{
	@Autowired
	AccountService accountService;

	@PostMapping("/account")
	public ResponseEntity<AccountResponseDto> saveAccountDetails(@Valid @RequestBody AccountRequestDto accountRequestDto) throws CustomerNotFoundException
	{
		AccountResponseDto accountResponseDto;
		try
		{
			accountResponseDto = accountService.saveAccountInformation(accountRequestDto);
		}
		catch(CustomerNotFoundException cnfex)
		{
			throw new CustomerNotFoundException("Customer not exist for Id" + accountRequestDto.getCustomerId());
		}
		return new ResponseEntity<AccountResponseDto>(accountResponseDto,HttpStatus.CREATED); 
	}

	@GetMapping("/account")
	public List<AccountResponseDto> getAllAccountDetails()
	{
		return accountService.getAllAccountInformation();
	}
}


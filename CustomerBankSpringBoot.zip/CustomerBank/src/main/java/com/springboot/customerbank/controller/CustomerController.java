package com.springboot.customerbank.controller;

import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import com.springboot.customerbank.dto.CustomerRequestDto;
import com.springboot.customerbank.dto.CustomerResponseDto;
import com.springboot.customerbank.service.CustomerService;

@RestController
public class CustomerController 
{
	@Autowired
	CustomerService customerService;

	@PostMapping("/customers")
	public ResponseEntity<String> saveCustomerDetails(@RequestBody CustomerRequestDto customerRequestDto)
	{
		customerService.saveCustomerDetails(customerRequestDto);
		return new ResponseEntity<String>("Entered Customer Detail Added Successfully",HttpStatus.ACCEPTED); 
	}

	@GetMapping("/customer")
	List<CustomerResponseDto> getCustomerDetails(@RequestParam String name)
	{
		return customerService.getCustomerDetails(name);
	}

	@GetMapping("/customers/{customerId}")
	public CustomerResponseDto getCustomerDetails(Integer customerId)
	{
		return customerService.getCustomerDetails(customerId);
	}

	@GetMapping("/customers")
	public ResponseEntity<List <CustomerResponseDto>>getCustomerDetails()
	{
		List<CustomerResponseDto> customerResponseList = customerService.getCustomerDetails();
		if(customerResponseList.size() <= 0)
		{
			return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
		}
		return ResponseEntity.of(Optional.of(customerResponseList));
	}

	@DeleteMapping(value="/customers/{customerId}")
	public ResponseEntity<String> deleteCustomerDetails(@PathVariable Integer customerId) 
	{
		customerService.deleteCustomerDetails(customerId);
		return new ResponseEntity("customer data deleted",HttpStatus.ACCEPTED);
	}
}

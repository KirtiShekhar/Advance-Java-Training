package com.springboot.customerbank.service.implementation;

import java.util.Optional;

import javax.persistence.EntityNotFoundException;
import javax.validation.Valid;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.springboot.customerbank.dto.BeneficiaryRequestDto;
import com.springboot.customerbank.dto.BeneficiaryResponseDto;
import com.springboot.customerbank.repository.BeneficiaryRepository;
import com.springboot.customerbank.service.BeneficiaryService;
import com.springboot.customerbank.entity.Beneficiary;
import com.springboot.customerbank.exception.BeneficiaryNotFoundException;

@Service
public class BeneficiaryServiceImplementation implements BeneficiaryService 
{
	@Autowired
	BeneficiaryRepository beneficiaryRepository;

	@Transactional(rollbackFor = Exception.class,noRollbackFor = EntityNotFoundException.class)
	public boolean addBeneficiary(@Valid BeneficiaryRequestDto beneficiaryRequestDto) 
	{
		// TODO Auto-generated method stub
		Beneficiary beneficiaryAccount=new Beneficiary();
		BeanUtils.copyProperties(beneficiaryRequestDto, beneficiaryAccount);
		Beneficiary beneficiarySaved =  beneficiaryRepository.save(beneficiaryAccount);
		if(beneficiarySaved!=null)
		{
			return true;
		}
		else
		{
			return false;
		}
	}


	@Transactional(rollbackFor = Exception.class,noRollbackFor = EntityNotFoundException.class)
	public String deleteBeneficiaryData(Integer beneficiaryId) 
	{

		Optional<Beneficiary> optionalbeneficiary = beneficiaryRepository.findById(beneficiaryId);
		if(optionalbeneficiary.isPresent())
		{
			Beneficiary beneficiary=beneficiaryRepository.findByBeneficiaryId(beneficiaryId);
			beneficiaryRepository.delete(beneficiary);
			return "beneficiary Deleted";
		}
		throw new BeneficiaryNotFoundException("Beneficiary not found");
		
	}

}

package com.springboot.customerbank.dto;

/*public class CustomerProjection 
 * {
 }*/
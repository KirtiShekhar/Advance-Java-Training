package com.springboot.customerbank.dto;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

public class BeneficiaryRequestDto {

	@NotNull(message = "Account Number cannot be null")
	@NotEmpty(message = "Account Number cannot be empty")
	private Long accountNumber;
	@NotNull(message = "Bemeficiary Account Number cannot be null")
	@NotEmpty(message = "Bemeficiary Account Number cannot be empty")
	private Long beneficiaryAccount;
	@NotNull(message = "Bemeficiary Name cannot be null")
	@NotEmpty(message = "Bemeficiary Name cannot be empty")
	private String beneficiaryName;
	
	
	
	
	public String getBeneficiaryName() {
		return beneficiaryName;
	}
	public void setBeneficiaryName(String beneficiaryName) {
		this.beneficiaryName = beneficiaryName;
	}
	public Long getAccountNumber() {
		return accountNumber;
	}
	public void setAccountNumber(Long accountNumber) {
		this.accountNumber = accountNumber;
	}
	public Long getBeneficiaryAccount() {
		return beneficiaryAccount;
	}
	public void setBeneficiaryAccount(Long beneficiaryAccount) {
		this.beneficiaryAccount = beneficiaryAccount;
	}



}
package com.springboot.customerbank.service;

import com.springboot.customerbank.dto.BeneficiaryRequestDto;

public interface BeneficiaryService {

	boolean addBeneficiary(BeneficiaryRequestDto beneficiaryRequestDto);
	
	String deleteBeneficiaryData(Integer beneficiaryId);

}

package com.springboot.customerbank.serviceImplementation;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.springboot.customerbank.dto.BeneficiaryRequestDto;
import com.springboot.customerbank.dto.BeneficiaryResponseDto;
import com.springboot.customerbank.entity.Account;
import com.springboot.customerbank.entity.Beneficiary;
import com.springboot.customerbank.repository.BeneficiaryRepository;
import com.springboot.customerbank.service.implementation.BeneficiaryServiceImplementation;

@ExtendWith(MockitoExtension.class)
class BeneficiaryServiceImplementationTest 
{
	@Mock
	BeneficiaryRepository beneficiaryRepository;

	@InjectMocks
	BeneficiaryServiceImplementation beneficiaryServiceImplementation;
	
	BeneficiaryRequestDto beneficiaryRequestDto;
	BeneficiaryResponseDto beneficiaryResponseDto;
	Beneficiary beneficiary;
	

	@BeforeEach
	public void setUp() throws Exception {
		beneficiaryRequestDto=new BeneficiaryRequestDto();
		beneficiaryRequestDto.setBeneficiaryName("Kirti Shekhar");
		beneficiaryRequestDto.setAccountNumber(66902545L);
		beneficiaryRequestDto.setBeneficiaryAccount(2489630L);
		
	}
	
	
	@Test
	@DisplayName("Save Beneficiary Details: Positive")
	public void addBeneficiaryTest_Positive()
	{
		when(beneficiaryRepository.save(any(Beneficiary.class))).thenAnswer(i ->{
			Beneficiary beneficiary = i.getArgument(0);
			beneficiary.setBeneficiaryId(1);
			return beneficiary;
		});
		//event
		boolean beneficiarysaveresult = beneficiaryServiceImplementation.addBeneficiary(beneficiaryRequestDto);
		//outcome
		assertTrue(beneficiarysaveresult);
	}
	
	@Test
	@DisplayName("Save Beneficiary Details: Negative")
	public void addBeneficiaryTest_Negative()
	{
		// context
				when(beneficiaryRepository.save(any(Beneficiary.class))).thenReturn(null);
				//event
				boolean accountsaveresult = beneficiaryServiceImplementation.addBeneficiary(beneficiaryRequestDto);;
				//outcome
				assertFalse(accountsaveresult);
	}

}
